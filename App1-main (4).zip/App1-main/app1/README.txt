Integrantes: 

Flavio Bustamante, Ignacio Vargas y Vicente Blanco

correos:

flbustamante@alumnos.uai.cl, ignvargas@lumnos.uai.cl, vicblanco@alumnos.uai.cl

compilador:

gcc -o programa main.c csv_reader.c orders.c metrics.c

para ejecutar el programa se debe poner en el mismo directorio el comando

.\app1 ventas.csv pms pls dls dms ………